<footer class="mt-auto" style="background-color: #2794bf; border-top: 6px solid #2485aa;">
<br />
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h5 class="text-white">SUPER POLLING</h5>
				<p class="text-white p-detail no-td-space">&copy; Super Polling 2021</p>
			</div>
			<div class="col-md-6">
				<ul class="footer-links text-right">
					<li class="foot-links"><a class="foot-nav-link" href="?pg=howitworks">How it works?</a></li>
					<li class="foot-links"><a class="foot-nav-link" href="?pg=about">About</a></li>
				</ul>
			</div>
		</div>
	</div>
	<br />
</footer>