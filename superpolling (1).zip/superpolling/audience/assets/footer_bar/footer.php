<footer class="mt-auto" style="background-color: #2794bf; border-top: 6px solid #2485aa;">
<br />
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h5 class="text-white">SUPER POLLING</h5>
				<p class="text-white p-detail no-td-space">&copy; Super Polling 2021</p>
			</div>
			<div class="col-md-6">
				<p class="p-detail text-white">
					Super Polling will help one to create a poll and get a Live Polls from invited peoples.
				</p>
			</div>
		</div>
	</div>
	<br />
</footer>